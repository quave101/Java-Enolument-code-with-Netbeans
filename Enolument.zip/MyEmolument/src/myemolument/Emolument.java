/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package myemolument;

/**
 *
 * @author Lenovo
 */
public class Emolument {
    // encapsolution 
    private double basic_salary;
    private double tax_relief;
    
    public double getBasicSalary(){
     return basic_salary;   
    }
    public double getTaskRelief(){
     return tax_relief;
    }
    //setters
    
    
    
    
    
    // constractor 

    public Emolument(double basic_salary, double task_relief) {
        this.basic_salary = basic_salary;
        this.tax_relief = task_relief;
    }
    public double SSNIT(){
return (35/100)*basic_salary;
}
    public double TaxableIncome(){
    return basic_salary - (SSNIT() + tax_relief );
    }
    
}
