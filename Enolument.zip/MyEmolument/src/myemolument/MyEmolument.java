/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package myemolument;

import java.util.Scanner;

/**
 *
 * @author Lenovo
 */




public class MyEmolument extends Emolument {
    double basic_salary;
    double tax_relief;
    
     
     public MyEmolument(){
      super(0, 0);  
}
public MyEmolument(double basic_salary, double tax_relief) {
        super(basic_salary, tax_relief);
    }
     public double IncomeTax(){
         
     if (TaxableIncome()<=500)
         return TaxableIncome() * 0.05;
     
     else if(TaxableIncome()<= 1000)
         return (500*0.05) + ((TaxableIncome()-500)*0.125);
     else
         return (500*0.05)+(500*0.125)+((TaxableIncome()-1000)*(17.5/100));

     }
     public double TotalDeductions(){
     return SSNIT() + IncomeTax() ;
     }
    public double NetSalary(){
        return getBasicSalary()-TotalDeductions();
    }
    
     public void display(){
        System.out.println("your Monthy pay is "+NetSalary());
        System.out.println("your Income Tax is "+IncomeTax());
     }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        //MyEmolument wow= new MyEmolument(3000, 1000);
        
         
        Scanner input = new Scanner(System.in);

        System.out.print("Enter your basic Salary: ");
        double basicSalaryInput = input.nextDouble();

        System.out.print("Enter your tax relief: ");
        double taxReliefInput = input.nextDouble();

        MyEmolument wow = new MyEmolument(basicSalaryInput, taxReliefInput);
        wow.display();
    }

   
    
}
